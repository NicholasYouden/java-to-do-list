import java.util.ArrayList;
import java.util.Scanner;

public class ToDoList {
    private ArrayList<String> items;

    public ToDoList() {
        items = new ArrayList<String>();
    }

    public void addItem(String item) {
        items.add(item);
    }

    public void removeItem(int index) {
        items.remove(index);
    }

    public void printList() {
        for (int i = 0; i < items.size(); i++) {
            System.out.println((i+1) + ". " + items.get(i));
        }
    }

    public static void main(String[] args) {
        ToDoList list = new ToDoList();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Enter a command (add, remove, print, quit):");
            String command = scanner.nextLine();

            if (command.equals("add")) {
                System.out.println("Enter the item to add:");
                String item = scanner.nextLine();
                list.addItem(item);
            } else if (command.equals("remove")) {
                System.out.println("Enter the index of the item to remove:");
                int index = scanner.nextInt();
                scanner.nextLine();
                list.removeItem(index);
            } else if (command.equals("print")) {
                list.printList();
            } else if (command.equals("quit")) {
                break;
            } else {
                System.out.println("Invalid command. Please try again.");
            }
        }

        System.out.println("Goodbye!");
        scanner.close();
    }
}